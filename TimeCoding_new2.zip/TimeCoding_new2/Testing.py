import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sn
import math
from Model import SNN
from definitions import *
from DataImport import *
from Classes import test, CreateClasses

def analyse(pred, labels):
    n = len(pred)
    LL = LR = RL = RR = 0
    for k in range(n):
        if (pred[k] == labels[k] and pred[k] == "left"):
            LL += 1
        if (pred[k] == labels[k] and pred[k] == "right"):
            RR += 1
        if (pred[k] != labels[k] and pred[k] == "left"):
            LR += 1
        if (pred[k] != labels[k] and pred[k] == "right"):
            RL += 1
    conf_matr = np.array([[LL, LR], [RL, RR]])
    show_confusion_matrix(conf_matr, "Expert view", "System's view") # матрица неточностей
    if np.linalg.det(conf_matr) == 0: 
        precision = 0
    else:
        precision_left = LL/(LL+LR)
        precision_right = RR/(RL+RR)
        precision = (precision_left+precision_right)/2
    recall_left = LL/(LL+RL)
    recall_right = RR/(RR+LR)
    recall = (recall_left+recall_right)/2
    if LL == RR == 0:
        F1_score = 0
    else:
        F1_score = 2*precision*recall/(precision+recall)
    return precision, recall, F1_score 

def show_confusion_matrix(conf_matr, xlabel, ylabel, annotate=True):
    df_cm = pd.DataFrame(conf_matr, index = [k for k in range(conf_matr.shape[0])],
              columns = [k for k in range(conf_matr.shape[1])])
    plt.figure(figsize = (8,5))
    ax = plt.axes()
    sn.heatmap(df_cm, annot=annotate, ax=ax)
    ax.set_xticks([0.5, 1.5])
    ax.set_xticklabels(["Left", "Right"])
    ax.set_yticks([0.5, 1.5])
    ax.set_yticklabels(["Left", "Right"])
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    plt.show()

def draw_intensity(intensity_samples, minI, maxI):
    x = np.arange(-0.5, ni, 1)
    y = np.arange(-0.5, 2, 1)
    fig, ax = plt.subplots(figsize=(10,5))
    ax.set_xticks(range(ni))
    ax.set_yticks([0, 1])
    ax.set_yticklabels(["Left", "Right"])
    ax.pcolormesh(x, y, intensity_samples, cmap='gray', vmin=minI, vmax=maxI)
    #for k in x:
      #plt.axvline(k, ls='-', c='w', lw=4) # white line between bars
    for k in y:
      plt.axhline(k, ls='-', c='black', lw=20)

def predict(snn, test_times, classes):
    pred = []
    for times_sample in test_times:
        spike_num = np.asarray(test(snn, times_sample))
        pred += [classes[spike_num.argmax()]]
    return pred

def decrease_contrast(current_test_times, coef):
    for k in range(n_test):
        times_sample = current_test_times[k]
        new_times_sample = coef*times_sample + (1-coef)*sum(times_sample)/ni
        current_test_times[k] = new_times_sample

def plot_F1_score_change(f1):
    axes_x = np.array([20*math.log10(256*(0.7**i)/10) for i in range(len(f1))])
    plt.plot(axes_x, f1)
    plt.plot(axes_x, f1, marker = '*')
    plt.xlabel("signal / noise, Db")
    plt.ylabel("F1-score value")
    plt.title("F1-score curve")


(test_left_spike_times, test_right_spike_times) = DataImport(False)

with open(file_path_delays, 'rb') as f:
    shifts = np.load(f) * b2.second
snn = SNN(nn, ni, 0, shifts)

classes = CreateClasses(snn)

test_times = np.hstack([test_left_spike_times, test_right_spike_times]).reshape(n_test, ni)
labels = ["left", "right"]*(n_test//2)
acc_f1 = []

for i in range(2):
    print(f"----------------------EXPERIMENT {i+1}---------------------------")
    print("Mean test time:")
    mean_test_time_left = np.mean(test_times[0:n_test-1:2], axis = 0)
    mean_test_time_right = np.mean(test_times[1:n_test:2], axis = 0)
    print(mean_test_time_left//1)
    print(mean_test_time_right//1)
    draw_intensity(np.vstack((mean_test_time_left, mean_test_time_right)), min_spike_time, max_spike_time)
    pred = predict(snn, test_times, classes)
    precision, recall, F1_score = analyse(pred, labels)
    acc_f1.append(F1_score)
    print("Precision: ", precision)
    print("Recall: ", recall)
    print("F1_score: ", F1_score) # F1 мера (сбалансированная мера)
    decrease_contrast(test_times, 0.7)

plot_F1_score_change(np.array(acc_f1))

plt.show()
