import os
import brian2 as b2
import numpy as np
import matplotlib.pyplot as plt
from Model import SNN
from definitions import *
from DataImport import *

def show_plots(e_state_mon, s_state_mon, i_spike_mon, e_spike_mon, ind_input):
    NS = min(len(ind_input), 4) 
    NN = nn
    plt.figure()
    for n in range(NN):
        for s in range(NS):
            sp_cell = NS * 100 + NN * 10 + s * NN + n + 1 # subplot coordinate
            if (n==0 and s==0): sp0 = plt.subplot(sp_cell) # make equal scales
            else: plt.subplot(sp_cell, sharex=sp0, sharey=sp0)
            plt.plot(s_state_mon.t/b2.ms, (s_state_mon.shift[ind_input[s] * NN + n] + s_state_mon.shift_correction[ind_input[s] * NN + n]) / b2.ms , label=f'delay of n={n} s={ind_input[s]}')
            for t in i_spike_mon.spike_trains()[ind_input[s]]:
                plt.axvline(t/b2.ms, ls='--', c='C1', lw=1) # orange == input
            for t in e_spike_mon.spike_trains()[n]:
                plt.axvline(t/b2.ms, ls='--', c='C2', lw=1) # green == main
            plt.legend()
            plt.xlabel("t, ms")
    plt.figure()
    for n in range(NN):
        if (n==0): sp1 = plt.subplot(NN*100 + 10*1 + n + 1) # make equal scales
        else: plt.subplot(NN*100 + 10*1 + n + 1, sharex=sp1, sharey=sp1)
        plt.plot(e_state_mon.t/b2.ms, e_state_mon.v[n]/b2.mV, label='v')
        plt.plot(e_state_mon.t/b2.ms, e_state_mon.vt_n[n]/b2.mV , label='v_T')
        #plt.plot(e_state_mon.t/b2.ms, e_state_mon.g_n[n] , label='g_n')
        for t in i_spike_mon.t:
            plt.axvline(t/b2.ms, ls='--', c='C1', lw=1) # orange == input
        for t in e_spike_mon.spike_trains()[n]:
            plt.axvline(t/b2.ms, ls='--', c='C2', lw=1) # green == main
        plt.legend()
        plt.xlabel("t, ms")
        plt.ylabel(f"v, mV   (n={n})")

(train_left_spike_time, train_right_spike_time) = DataImport(True)

if os.path.exists(file_path_initial_delays):
    with open(file_path_initial_delays, 'rb') as f:
        shifts = np.load(f) * b2.second
else:
    shifts = b2.rand(ni*nn) * max_spike_time * b2.ms
    np.save(file_path_initial_delays, shifts)

snn = SNN(nn, ni, 1, shifts)

e_state_mon = b2.StateMonitor(snn.group_n, ['v', 'vt_n', 'g_n'], record=True)
s_state_mon = b2.StateMonitor(snn.synapses_e, ['shift', 'shift_correction'], record=True)
i_spike_mon = b2.SpikeMonitor(snn.input_group)
e_spike_mon = b2.SpikeMonitor(snn.group_n)
snn.net.add(e_state_mon)
snn.net.add(s_state_mon)
snn.net.add(i_spike_mon)
snn.net.add(e_spike_mon)

#num = n_train // 2
num = 1
for i in range(num):
    snn.input_group.set_spikes(list(range(ni)), train_left_spike_time[0] * b2.ms, train_period)
    snn.net.run(150 * b2.ms)
    snn.input_group.set_spikes(list(range(ni)), [30000]*ni * b2.ms, 0 * b2.ms)
    snn.net.run(60 * b2.ms)

    snn.input_group.set_spikes(list(range(ni)), train_right_spike_time[0] * b2.ms, train_period)
    snn.net.run(150 * b2.ms)
    snn.input_group.set_spikes(list(range(ni)), [30000]*ni * b2.ms, 0 * b2.ms)
    snn.net.run(60 * b2.ms)

    snn.input_group.set_spikes(list(range(ni)), [10,8,6,4,2,2,4,6,8,10] * b2.ms, train_period)
    snn.net.run(150 * b2.ms)
    snn.input_group.set_spikes(list(range(ni)), [30000]*ni * b2.ms, 0 * b2.ms)
    snn.net.run(60 * b2.ms)

ind_input_to_show = [0,9]
show_plots(e_state_mon, s_state_mon, i_spike_mon, e_spike_mon, ind_input_to_show)
snn.net.remove(e_state_mon)
snn.net.remove(s_state_mon)
snn.net.remove(i_spike_mon)
snn.net.remove(e_spike_mon)


# delays = (snn.synapses_e.shift/b2.ms*10//1).reshape(ni,nn).transpose()
# print("Initial delays:")
# print(delays)
# plt.figure()
# for i in range(nn):
#     plt.plot(np.arange(1,ni + 1,1), delays[i])
#     # plt.plot(np.arange(1,11,1), delays[i], marker = '*')
#     plt.legend(f"delays_to_{i}")
# plt.xlabel("delays_index")
# plt.ylabel("delays_values, ms")
# plt.title("Initial delays values")
# plt.show()

np.save(file_path_delays, snn.synapses_e.shift)
delays = (snn.synapses_e.shift/b2.ms*10//1).reshape(ni,nn).transpose()
print("Final delays:")
print(delays)
plt.figure()
for i in range(nn):
    plt.plot(np.arange(1,ni + 1,1), delays[i])
    # plt.plot(np.arange(1,11,1), delays[i], marker = '*')
    plt.legend(f"delays_to_{i}")
plt.xlabel("delays_index")
plt.ylabel("delays_values, ms")
plt.title("Final delays values")
plt.show()

