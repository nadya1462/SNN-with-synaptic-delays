import brian2 as b2

min_intensity = 0
max_intensity = 100
data_size = 100
noise_sigma = 2 # standard deviation
min_spike_time = 1 # ms
max_spike_time = 10 # ms    # tau_n << max_spike_time / ni  !!! (train = max_spike_time)

n_train = 10
n_test = 20

train_period = 30 * b2.ms  # we will have 7 periods for one image (350 ms) = 7 output spikes
nn = 3
ni = 10

file_path_left = 'data_left_spike_time.npy'
file_path_right = 'data_right_spike_time.npy'

file_path_delays = 'axons_delays.npy'
file_path_initial_delays = 'axons_initial_delays.npy'


